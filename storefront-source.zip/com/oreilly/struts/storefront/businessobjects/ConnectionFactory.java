package com.oreilly.struts.storefront.businessobjects;

import net.sf.hibernate.HibernateException;
import net.sf.hibernate.MappingException;
import net.sf.hibernate.Session;
import net.sf.hibernate.SessionFactory;
import net.sf.hibernate.cfg.Configuration;

/*
 * This class was created to encapsulate the Hibernate SessionFactory and assist
 * the service layer.
 *
 */
public class ConnectionFactory
{

	private static ConnectionFactory instance = null;
	private SessionFactory sessionFactory = null;

	private ConnectionFactory()
	{
		// Establish SessionFactory for Hibernate
		try
		{

			/*
			 * The Hibernate Configuration will contain all the classes to be
			 * persisted by Hibernate.  For each class persisted, Hibernate will
			 * expect to find a ClassName.hbm.xml file in the same location as the
			 * class file.  This XML file will define the mapping between the Java
			 * object and the database.
			 *
			 * To add additional classes to the configuration, you may cascade the
			 * method calls thusly:
			 *
			 * Configuration cfg = new Configuration().
			 *                         addClass(Foo.class).
			 *                         addClass(Bar.class);
			 *
			 */
			Configuration cfg = new Configuration().addClass(CustomerBO.class).addClass(ItemBO.class);

			sessionFactory = cfg.buildSessionFactory();

		}
		catch (MappingException e)
		{
			/*
			 * Upon encountering a Hibernate generated Exception, we are throwing
			 * an unchecked RuntimeExcpetion that will cause the user's
			 * request to fail.
			 *
			 */
			e.printStackTrace();
		}
		catch (HibernateException e)
		{
			e.printStackTrace();
		}

	}

	/**
	 * getInstance() returns the instance of the ConnectionFactory singleton.
	 *
	 * Example call to retrieve session:
	 *
	 * <pre>
	 * Session session = ConnectionFactory.getInstance().getSession();
	 * </pre>
	 *
	 * @return Instance of the <code>ConnectionFactory</code> singleton.
	 */
	public static synchronized ConnectionFactory getInstance()
	{
		/*
		 * If the instance of the Singleton has not been created, create and
		 * return.
		 */
		if (instance == null)
		{
			instance = new ConnectionFactory();
		}
		return instance;
	}

	/**
	 * getSession() returns a Hibernate <code>Session</code>
	 *
	 * @return <code>Session</code> retrieved from Hibernate <Code>SessionFactory</code>
	 */
	public Session getSession()
	{
		Session s = null;
		try
		{
			/*
			 * Use the Hibernate Session Factory to return an open session to the caller.
			 */
			s = sessionFactory.openSession();			
		}
		catch (HibernateException e){
			e.printStackTrace();
		}
		return s;
	}

}
