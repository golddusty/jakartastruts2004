package com.oreilly.struts.storefront.framework.exceptions;

/**
 * This exception is used to report an error that occurs with a particular
 * message request.
 */
public class DataRequestException extends Exception {
  public DataRequestException() {

  }
}
