package com.oreilly.struts.storefront.framework.exceptions;

public class FieldException extends BaseException {
  public FieldException() {

  }
}
