package com.oreilly.struts.storefront.framework.exceptions;

/**
 * This application exception is used to report a problem with a method
 * argument.
 */
public class InvalidArgumentException extends Exception {
  public InvalidArgumentException() {

  }
}
