package com.oreilly.struts.storefront.security;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.oreilly.struts.storefront.customer.view.UserView;
import com.oreilly.struts.storefront.framework.StorefrontBaseAction;
import com.oreilly.struts.storefront.framework.UserContainer;
import com.oreilly.struts.storefront.framework.util.IConstants;
import com.oreilly.struts.storefront.service.IStorefrontService;
import com.oreilly.struts.storefront.service.IStorefrontServiceFactory;
/**
 * Implements the logic to authenticate a user for the storefront application.
 */
public class LoginAction extends StorefrontBaseAction {
  protected static Log log = LogFactory.getLog( StorefrontBaseAction.class );
  /**
   * Called by the controller when the a user attempts to login to the
   * storefront application.
   */
  public ActionForward execute( ActionMapping mapping,
                                ActionForm form,
                                HttpServletRequest request,
                                HttpServletResponse response )
  throws Exception{

    // Get the user's login name and password. They should have already
    // validated by the ActionForm.
    String email = ((LoginForm)form).getEmail();
    String password = ((LoginForm)form).getPassword();

    // Get the StorefrontServiceFactory
    IStorefrontServiceFactory factory = (IStorefrontServiceFactory)
    servlet.getServletContext().getAttribute( IConstants.SERVICE_FACTORY_KEY );
    
    IStorefrontService service = null;

    // Create the Service
    try{
      service = factory.createService();
    }catch( Exception ex ){
      log.error( "Problem creating the Storefront Service", ex );
    }
    
    // Attempt to authenticate the user
    UserView userView = service.authenticate(email, password);

    // Store the user object into the HttpSession
    UserContainer existingContainer = getUserContainer(request);
    existingContainer.setUserView(userView);
    return mapping.findForward(IConstants.SUCCESS_KEY);
  }
}