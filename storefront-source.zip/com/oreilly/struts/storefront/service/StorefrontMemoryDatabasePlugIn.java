package com.oreilly.struts.storefront.service;

import javax.servlet.ServletException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.struts.action.ActionServlet;
import org.apache.struts.config.ModuleConfig;
import org.apache.struts.webapp.example.memory.MemoryDatabasePlugIn;

import com.oreilly.struts.storefront.framework.util.IConstants;

public final class StorefrontMemoryDatabasePlugIn
	extends MemoryDatabasePlugIn {
	private ModuleConfig config = null;
	private Log log = LogFactory.getLog(this.getClass());
	private ActionServlet servlet = null;
	private String serviceClassname = null;

	/**
	 * Gracefully shut down this database, releasing any resources
	 * that were allocated at initialization.
	 */
	public void destroy() {
		// Do Nothing
	}

	/**
	 * Initialize and load our initial database from persistent storage.
	 *
	 * @param servlet The ActionServlet for this web application
	 * @param config The ModuleConfig for our owning module
	 *
	 * @exception ServletException if we cannot configure ourselves correctly
	 */
	public void init(ActionServlet servlet, ModuleConfig config)
		throws ServletException {

		log.info(
			"Initializing memory database plug in for '"
				+ serviceClassname
				+ "'");

		// Remember our associated configuration and servlet
		this.config = config;
		this.servlet = servlet;

		IStorefrontServiceFactory factory = null;

		try {
			factory = StorefrontServiceFactory.getInstance();
		} catch (Exception ex) {
			throw new ServletException(ex.getMessage());
		}

		// Put the Factory in the ServletContent so that it's available for client
		servlet.getServletContext().setAttribute(
			IConstants.SERVICE_FACTORY_KEY,
			factory);
	}

	public String getServiceClassname() {
		return serviceClassname;
	}

	public void setServiceClassname(String string) {
		serviceClassname = string;
	}
}
