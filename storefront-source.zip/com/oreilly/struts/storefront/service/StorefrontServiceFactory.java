package com.oreilly.struts.storefront.service;

import javax.servlet.ServletException;

import org.apache.struts.action.ActionServlet;
import org.apache.struts.action.PlugIn;
import org.apache.struts.config.ModuleConfig;

import com.oreilly.struts.storefront.framework.util.IConstants;

/**
 * A factory for creating Storefront Service Implementations. The specific
 * service to instantiate is determined from the initialization parameter
 * of the ServiceContext. Otherwise, a default implementation is used.
 * @see com.oreilly.struts.storefront.service.StorefrontDebugServiceImpl
 */
public class StorefrontServiceFactory implements IStorefrontServiceFactory {

	// The default is to use the debug implementation
	private static String serviceClassname =
		"com.oreilly.struts.storefront.service.StorefrontDebugServiceImpl";

	private static IStorefrontServiceFactory Singleton = null;

	public static IStorefrontServiceFactory getInstance() {

		synchronized (StorefrontServiceFactory.class) {
			if (Singleton == null) {
				Singleton = new StorefrontServiceFactory();
				return Singleton;
			}
		}
		return Singleton;
	}

	private StorefrontServiceFactory() {
		init();
	}

	public void init() {
		IStorefrontService service = null;
		try {

			service =
				(IStorefrontService) Class
					.forName(serviceClassname)
					.newInstance();
		} catch (Exception ex) {
			
			// Swallow the exception and let it occur during the createService() method call.
			ex.printStackTrace();
		}
	}

	public IStorefrontService createService()
		throws
			ClassNotFoundException,
			IllegalAccessException,
			InstantiationException {		
		
		return (IStorefrontService) Class
			.forName(getServiceClassname())
			.newInstance();
	}

	/**
	 * @return
	 */
	public static String getServiceClassname() {
		return serviceClassname;
	}

	/**
	 * @param string
	 */
	public static void setServiceClassname(String string) {
		serviceClassname = string;
	}
}