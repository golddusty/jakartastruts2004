package com.oreilly.struts.storefront.service;

import java.sql.Timestamp;
import java.util.List;
import java.util.ArrayList;
import com.oreilly.struts.storefront.catalog.view.ItemDetailView;
import com.oreilly.struts.storefront.catalog.view.ItemSummaryView;
import com.oreilly.struts.storefront.framework.security.IAuthentication;
import com.oreilly.struts.storefront.customer.view.UserView;
import com.oreilly.struts.storefront.businessobjects.*;
// Import the exceptions used
import com.oreilly.struts.storefront.framework.exceptions.DatastoreException;
import com.oreilly.struts.storefront.framework.exceptions.InvalidLoginException;
import com.oreilly.struts.storefront.framework.exceptions.ExpiredPasswordException;
import com.oreilly.struts.storefront.framework.exceptions.AccountLockedException;
import javax.servlet.ServletContext;

// Import the implementation specific packages
import net.sf.hibernate.Hibernate;
import net.sf.hibernate.cfg.Configuration;
import net.sf.hibernate.Transaction;
import net.sf.hibernate.Session;
import net.sf.hibernate.SessionFactory;
import net.sf.hibernate.Query;
import net.sf.hibernate.type.Type;

public class StorefrontServiceImpl implements IStorefrontService{

  // The SessionFactory
  SessionFactory sessionFactory = null;

  /**
   * Create the service, which includes initializing the persistence
   * framework.
   */
  public StorefrontServiceImpl() throws DatastoreException {
    super();
    init();
  }

  /**
   * Return a list of items that are featured.
   */
  public List getFeaturedItems() throws DatastoreException {
    List items = null;
    Session session = null;

    try{
      session = sessionFactory.openSession();
      Query q = session.createQuery("from ItemBO item");
      List results = q.list();

      int size = results.size();
      items = new ArrayList();

      for( int i = 0; i < size; i++ ){
        ItemBO itemBO = (ItemBO)results.get(i);
        ItemSummaryView newView = new ItemSummaryView();
        newView.setId( itemBO.getId().toString() );
        newView.setName( itemBO.getDisplayLabel() );
        newView.setUnitPrice( itemBO.getBasePrice() );
        newView.setSmallImageURL( itemBO.getSmallImageURL() );
        newView.setProductFeature( itemBO.getFeature1() );
        items.add( newView );
      }
      session.close();

    }catch( Exception ex ){
      ex.printStackTrace();
      throw DatastoreException.datastoreError(ex);
    }
    return items;
  }

  /**
   * Return an detailed view of an item based on the itemId argument.
   */
  public ItemDetailView getItemDetailView( String itemId )
  throws DatastoreException{
    ItemBO itemBO = null;
    Session session = null;

    try{
      session = sessionFactory.openSession();
      itemBO = (ItemBO) session.get(ItemBO.class, itemId);
      session.close();

    }catch( Exception ex ){
      ex.printStackTrace();
      throw DatastoreException.datastoreError(ex);
    }

      //
      if (itemBO == null ){
        throw DatastoreException.objectNotFound();
      }

      // Build a ValueObject for the Item
      ItemDetailView view = new ItemDetailView();
      view.setId( itemBO.getId().toString() );
      view.setDescription( itemBO.getDescription() );
      view.setLargeImageURL( itemBO.getLargeImageURL() );
      view.setName( itemBO.getDisplayLabel() );
      view.setProductFeature( itemBO.getFeature1() );
      view.setUnitPrice( itemBO.getBasePrice() );
      view.setTimeCreated( new Timestamp(System.currentTimeMillis() ));
      view.setModelNumber( itemBO.getModelNumber() );

      return view;
  }

  /**
   * Authenticate the user's credentials and either return a UserView for the
   * user or throw one of the security exceptions.
   */
  public UserView authenticate(String email, String password) throws
    InvalidLoginException,ExpiredPasswordException,AccountLockedException,
    DatastoreException {

      List results = null;
      try{
        Session session = sessionFactory.openSession();
        results =
           session.find(
            "from CustomerBO as cust where cust.email = ? and cust.password = ?",
            new Object[] { email, password },
            new Type[] { Hibernate.STRING, Hibernate.STRING } );

      }catch( Exception ex ){
        ex.printStackTrace();
        throw DatastoreException.datastoreError(ex);
      }

      // If no results were found, must be an invalid login attempt
      if ( results.isEmpty() ){
        throw new InvalidLoginException();
      }

      // Should only be a single customer that matches the parameters
      CustomerBO customer  = (CustomerBO)results.get(0);

      // Make sure the account is not locked
      String accountStatusCode = customer.getAccountStatus();
      if ( accountStatusCode != null && accountStatusCode.equals( "L" ) ){
        throw new AccountLockedException();
      }

      // Populate the Value Object from the Customer business object
      UserView userView = new UserView();
      userView.setId( customer.getId().toString() );
      userView.setFirstName( customer.getFirstName() );
      userView.setLastName( customer.getLastName() );
      userView.setEmailAddress( customer.getEmail() );
      userView.setCreditStatus( customer.getCreditStatus() );

      return userView;
    }

  /**
   * Log the user out of the system.
   */
  public void logout(String email){
    // Do nothing with right now, but might want to log it for auditing reasons
  }

  public void destroy(){
    // Do nothing for this example
  }

  private void init() throws DatastoreException {

    try{
      sessionFactory = new Configuration().configure().buildSessionFactory();
    }catch( Exception ex ){
      throw DatastoreException.datastoreError(ex);
    }
  }
}